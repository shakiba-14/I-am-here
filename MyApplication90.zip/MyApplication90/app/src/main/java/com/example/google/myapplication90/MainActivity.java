package com.example.google.myapplication90;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    EditText etID, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etID = (EditText) findViewById(R.id.etID);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                HashMap postData = new HashMap();
                postData.put("keyID", etID.getText().toString());
                postData.put("keyPassword", etPassword.getText().toString());

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(MainActivity.this, postData,new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {
                        if (s.contains("success")){
                            Toast.makeText(MainActivity.this, "Successfully login", Toast.LENGTH_LONG).show();


                        }
                        else{
                            Toast.makeText(MainActivity.this, "Try Again", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                task1.execute("http://192.168.8.111/busAttendance/login.php");

            }
        });


    }
}
